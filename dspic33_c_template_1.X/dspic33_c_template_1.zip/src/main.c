/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__dsPIC33E__)
    	#include <p33Exxxx.h>
    #elif defined(__dsPIC33F__)
    	#include <p33Fxxxx.h>
    #endif
#endif


#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */

/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/

/* i.e. uint16_t <variable_name>; */

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

int16_t main(void)
{

    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize IO ports and peripherals */
    InitApp();

    /* TODO <INSERT USER APPLICATION CODE HERE> */
    unsigned int dly;
    char         cnt;
    led1=0;
    led2=0;
    led3=0;
    led4=0;
    burner1=1;
    burner2=0;

    while(1)
    {
        if(button0==0){burner1=1;}else{burner1=0;}
        if(button1==0){burner2=1;}else{burner2=0;}
        if(++cnt>4){cnt=0;}
        for(dly=0;dly<65000;dly++);
        switch (cnt)
        {
          case 0x0001:
              led1=1;
              led2=0;
              led3=0;
              led4=0;
             break;
          case 0x0002:
              led1=0;
              led2=1;
              led3=0;
              led4=0;
             break;
          case 0x0003:
              led1=0;
              led2=0;
              led3=1;
              led4=0;
             break;
          case 0x0004:
              led1=0;
              led2=0;
              led3=0;
              led4=1;
             break;
          default:
              led1=0;
              led2=0;
              led3=0;
              led4=0;
             break;  


        }
    }
}
